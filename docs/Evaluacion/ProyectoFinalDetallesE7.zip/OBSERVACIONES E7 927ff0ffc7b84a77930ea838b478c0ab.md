# OBSERVACIONES E7

# PHP Y HTML

- Hace falta comentarios, ya sea una función que ustedes tienen muy clara o un  proceso que ustedes saben muy claramente para que es deben comentarlo pues para aquellos que lean su código en el futuro (incluso ustedes mismos) les resultará fácil comprender porqué hicieron tal cosa.

# BASES DE DATOS

 

## UML

- Cuiden la organización del diagrama pues en algunas partes puede llegar a ser confusa por tantas relaciones y curvas en las flechas puesto que algunas no están alineadas correctamente.
- El tipo de relación de usuario y administrador con tipo es incorrecto, hay una relación, si, pero no de herencia pues no tienen expresamente los atributos id_tipo y tipo.
- En algunas entidades falta el tipo de dato, y recuerden que el tipo de dato se pone después de ":"  precedido por el nombre del atributo.
- Hay algunas partes donde hay "1" como si se refiriera al tipo de relación, cuiden bien que elementos tienen en el diagrama.
- Cuidado con escribir bien los tipos pues en la entidad estado el atributo estado tiene "varcar", en la entidad  "respuests"  no existe en la base o se les fue una "a".
- En su diagrama no se encontró la entidad "imagen"

## Entidad Relación

- En el diagrama ER los atributos salen directamente de la entidad, no se van anidando o desplegando como lo hicieron.
- No se representan las llaves primarias
- No se representan las entidades débiles, solo se representan las fuertes. Por ejemplo su entidad encuesta seria débil pues depende de otras para existir (de acuerdo a como lo representaron en su diagrama UML).
- No se encontró la entidad "imagen".  Solo les falto esa entidad, pero tengan cuidado en agregar todo lo nuevo que se agrega, aun sea de último momento, pues a quien vaya a tener su sistema no se va a poner a checar la base, el esta confiado en que lo que este en los diagramas es lo que esta en la base.

## Diccionario de Datos

- En su base el atributo id_bloqueo de la entidad usuario si puede ser nulo, y en su diccionario ponen que no.

## Base de datos (terminal o respaldo)

- Entidad eliminado, bloqueo y administador
- Entidad encuesta: atributo nombre, se pudo poner un tipo diferente de "text" ya que es demasiado para el titulo de una encuesta.
- Entidad administrador: el contenido del atributo administrador no es claro.

No se pudo acceder al administrador por lo que no se pudo checar si las sentencias SQL funcionaban en su totalidad

# JAVASCRIPT

- En los formularios cuando no se lleno algún campo correctamente y se rechaza el formulario, lo correcto sería mandar un mensaje de error y decir que faltó, en su caso se recarga la página solamente y puede dar a entender que el registro fue exitoso.
- Siguiendo con lo anterior es importante que no le dejen la validación solo al html, también deben hacer un segundo filtro de validación en el servidor (php) y con js.
- Cuando se intenta acceder a la página de un usuario que no le corresponde, ni si quiere debe aparecerle la pantalla con las opciones, cosa que si se puede en su sistema, lo correcto seria ya sea redireccionarlo a la página de inicio o decirle que no tiene los permisos para estar en esa página.

# DISEÑO

- El uso de bootstrap fue demasiado limitado. Y no tiene adaptabilidad.
- Recuerden que el orden de los elementos en el css es de lo general a lo particular (de arriba a abajo en el código) y es importante que las propiedades estén en orden alfabético.

# SEGURIDAD

## Github

- Los commits deben llevar: Tipo, titulo, descripción. Ustedes solo pusieron Tipo y título

## ATAQUES

- En algún archivo php obtenían el dato con $_GET, y eso es inseguro, lo correcto sería $_POST

# Conclusión

Su proyecto demostró que tienen los conocimientos y el dominio para lograr terminarlo, lo que jugo en su contra fue la presión, el cansancio y la organización. El estar la mayoría en llamada haciendo el proyecto tiene sus ventajas pues si alguien se atrasa en algo o se "atora" en una parte del proyecto los demás pueden ayudarle, sin embargo, bien una persona con mejor dominio en el tema (mientras no este ocupada o no tenga tanta carga de trabajo) puede ayudarle, muchas veces el estar todo el equipo junto hace que se distraigan viendo lo que hace el otro o soltando bromas, esto último no es nada malo al contrario, pero recuerden que nada en exceso.

Sin duda mostraron cada uno un crecimiento enorme a comparación de como entraron al curso, sin embargo, el fin de una historia es el inicio de otra, ahora es su deber seguir creciendo y fortaleciéndose y por su puesto ayudar a otros a hacerlo.